class Heuristic:

    @staticmethod
    def h(node):
        return 0